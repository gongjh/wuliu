-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : wuliu
-- 
-- Part : #1
-- Date : 2013-12-31 10:29:01
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `wuliu_action`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_action`;
CREATE TABLE `wuliu_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `wuliu_action`
-- -----------------------------
INSERT INTO `wuliu_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '2', '1', '1383295068');
INSERT INTO `wuliu_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '2', '1', '1380173180');
INSERT INTO `wuliu_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '2', '1', '1383285646');
INSERT INTO `wuliu_action` VALUES ('4', 'add_document_blog', '发表博客', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '2', '1', '1383285637');
INSERT INTO `wuliu_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '2', '1', '1383285551');
INSERT INTO `wuliu_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '1', '1', '1383294988');
INSERT INTO `wuliu_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '1', '1', '1383295057');
INSERT INTO `wuliu_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '1', '1', '1383295963');
INSERT INTO `wuliu_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '1', '1', '1383296301');
INSERT INTO `wuliu_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '1', '1', '1383296392');
INSERT INTO `wuliu_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '1', '1', '1383296765');
INSERT INTO `wuliu_action` VALUES ('12', 'add', '新增即时货物', '新增即时货物信息', '', '2', '1', '1387869419');
INSERT INTO `wuliu_action` VALUES ('13', 'update', '修改即时货物信息', '修改即时货物信息', '', '2', '1', '1387871003');
INSERT INTO `wuliu_action` VALUES ('14', 'delete', '删除即时货物信息', '删除即时货物信息', '', '2', '1', '1387871930');
INSERT INTO `wuliu_action` VALUES ('15', 'put', '取货操作', '取货', '', '2', '1', '1387939532');
INSERT INTO `wuliu_action` VALUES ('16', 'back', '遣返操作', '遣返货物', '', '2', '1', '1387939581');
INSERT INTO `wuliu_action` VALUES ('17', 'export', '导出excel', '导出excel', '', '2', '1', '1387940168');
INSERT INTO `wuliu_action` VALUES ('18', 'addSendover', '新增已发货货物', '新增已发货货物', '', '2', '1', '1387953214');
INSERT INTO `wuliu_action` VALUES ('19', 'editSendover', '编辑已发货货物', '编辑已发货货物', '', '2', '1', '1387953241');
INSERT INTO `wuliu_action` VALUES ('20', 'removeSendover', '删除已发货货物', '删除已发货货物', '', '2', '1', '1387953264');
INSERT INTO `wuliu_action` VALUES ('21', 'exportSendover', '导出已发货货物', '导出已发货货物', '', '2', '1', '1387953731');
INSERT INTO `wuliu_action` VALUES ('22', 'addReturnGoods', '新增遣返货物', '新增遣返货物', '', '2', '1', '1387957506');
INSERT INTO `wuliu_action` VALUES ('23', 'editReturnGoods', '修改遣返货物信息', '修改遣返货物信息', '', '2', '1', '1387957585');
INSERT INTO `wuliu_action` VALUES ('24', 'RemoveReturnGoods', '删除遣返货物信息', '删除遣返货物信息', '', '2', '1', '1387957610');
INSERT INTO `wuliu_action` VALUES ('25', 'logout', '退出登录', '退出登录', '', '1', '1', '1388382359');
INSERT INTO `wuliu_action` VALUES ('26', 'updateSmsStatus', '更改短信状态', '更改短信状态', '', '1', '1', '1388387603');
INSERT INTO `wuliu_action` VALUES ('27', 'addContacts', '新增短信状态', '新增短信状态', '', '1', '1', '1388387647');
INSERT INTO `wuliu_action` VALUES ('28', 'updateRemark', '更改短信备注', '更改短信备注', '', '1', '1', '1388387694');

-- -----------------------------
-- Table structure for `wuliu_area_price`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_area_price`;
CREATE TABLE `wuliu_area_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `plusprice` int(11) NOT NULL,
  `discount` int(11) NOT NULL COMMENT '折扣',
  `company_id` int(11) NOT NULL,
  `city` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `wuliu_area_price`
-- -----------------------------
INSERT INTO `wuliu_area_price` VALUES ('1', '山东、天津、河南、河北', '12', '8', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('2', '江苏、浙江、上海、安徽、山西、陕西、黑龙江、辽宁、吉林、广东、湖南、湖北', '12', '8', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('3', '福建、广西、海南、重庆、四川、贵州、云南、甘肃、宁夏、内蒙古', '15', '12', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('4', '新疆、西藏、青海', '22', '20', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('5', '北京', '8', '3', '0', '3', '北京化工大学');

-- -----------------------------
-- Table structure for `wuliu_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_auth_extend`;
CREATE TABLE `wuliu_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `wuliu_auth_extend`
-- -----------------------------
INSERT INTO `wuliu_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '19', '2');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '20', '2');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '21', '2');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '22', '2');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '23', '2');
INSERT INTO `wuliu_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `wuliu_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_auth_group`;
CREATE TABLE `wuliu_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wuliu_auth_group`
-- -----------------------------
INSERT INTO `wuliu_auth_group` VALUES ('1', 'admin', '1', '北京化工大学物流站', '', '1', '1,108,109,211,212,213,214,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232');
INSERT INTO `wuliu_auth_group` VALUES ('3', 'admin', '1', '物流站', '', '1', '');

-- -----------------------------
-- Table structure for `wuliu_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_auth_group_access`;
CREATE TABLE `wuliu_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wuliu_auth_group_access`
-- -----------------------------
INSERT INTO `wuliu_auth_group_access` VALUES ('19', '1');
INSERT INTO `wuliu_auth_group_access` VALUES ('20', '1');
INSERT INTO `wuliu_auth_group_access` VALUES ('24', '2');
INSERT INTO `wuliu_auth_group_access` VALUES ('25', '2');
INSERT INTO `wuliu_auth_group_access` VALUES ('26', '1');

-- -----------------------------
-- Table structure for `wuliu_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_auth_rule`;
CREATE TABLE `wuliu_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`module`,`name`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=233 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wuliu_auth_rule`
-- -----------------------------
INSERT INTO `wuliu_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('6', 'admin', '1', 'Admin/Index/index', '首页', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addAction', '新增用户行为', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editAction', '编辑用户行为', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('211', 'admin', '1', 'Admin/sendonline/index', '即时货物信息', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('212', 'admin', '2', 'Admin/Sendonline/index', '取货', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Sendonline/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Sendonline/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('215', 'admin', '1', 'Admin/sendonline/remove', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Sendover/index', '已取货货物信息', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('217', 'admin', '1', 'Admin/ReturnGoods/index', '返还货物信息', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('218', 'admin', '2', 'Admin/receive/index', '收货', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('219', 'admin', '1', 'Admin/Statistics/index', '统计信息', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('220', 'admin', '1', 'Admin/sendonline/export', '导出excel', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('221', 'admin', '1', 'Admin/sendonline/put', '取货操作', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('222', 'admin', '1', 'Admin/sendonline/back', '遣返', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('223', 'admin', '1', 'Admin/Sendover/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('224', 'admin', '1', 'Admin/Sendover/edit', '修改', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('225', 'admin', '1', 'Admin/Sendover/remove', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('226', 'admin', '1', 'Admin/ReturnGoods/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('227', 'admin', '1', 'Admin/ReturnGoods/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('228', 'admin', '1', 'Admin/ReturnGoods/remove', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('229', 'admin', '1', 'Admin/receive/add', '新增', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('230', 'admin', '1', 'Admin/receive/edit', '编辑', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('231', 'admin', '1', 'Admin/receive/remove', '删除', '1', '');
INSERT INTO `wuliu_auth_rule` VALUES ('232', 'admin', '1', 'Admin/receive/export', '导出excel', '1', '');

-- -----------------------------
-- Table structure for `wuliu_config`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_config`;
CREATE TABLE `wuliu_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wuliu_config`
-- -----------------------------
INSERT INTO `wuliu_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '物流管理系统', '0');
INSERT INTO `wuliu_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '物流管理系统', '1');
INSERT INTO `wuliu_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '物流管理系统', '3');
INSERT INTO `wuliu_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '0');
INSERT INTO `wuliu_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '0');
INSERT INTO `wuliu_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '4');
INSERT INTO `wuliu_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐\r\n2:频道页推荐\r\n4:网站首页推荐', '0');
INSERT INTO `wuliu_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '0');
INSERT INTO `wuliu_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'blue_color', '5');
INSERT INTO `wuliu_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '0');
INSERT INTO `wuliu_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '0');
INSERT INTO `wuliu_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '0');
INSERT INTO `wuliu_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '0');
INSERT INTO `wuliu_config` VALUES ('24', 'AOTUSAVE_DRAFT', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1379484574', '1', '60', '0');
INSERT INTO `wuliu_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '5');
INSERT INTO `wuliu_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '0');
INSERT INTO `wuliu_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '0');
INSERT INTO `wuliu_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '0');
INSERT INTO `wuliu_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '0');
INSERT INTO `wuliu_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '0');
INSERT INTO `wuliu_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '0');
INSERT INTO `wuliu_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '0');

-- -----------------------------
-- Table structure for `wuliu_express`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_express`;
CREATE TABLE `wuliu_express` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '物流公司名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wuliu_express`
-- -----------------------------
INSERT INTO `wuliu_express` VALUES ('1', '顺丰快递');
INSERT INTO `wuliu_express` VALUES ('2', '汇通快递');
INSERT INTO `wuliu_express` VALUES ('3', '圆通快递');
INSERT INTO `wuliu_express` VALUES ('4', '中通快递');
INSERT INTO `wuliu_express` VALUES ('5', '申通快递');
INSERT INTO `wuliu_express` VALUES ('6', '韵达快递');
INSERT INTO `wuliu_express` VALUES ('7', 'EMS');
INSERT INTO `wuliu_express` VALUES ('8', '天天快递');
INSERT INTO `wuliu_express` VALUES ('9', '快捷快递');
INSERT INTO `wuliu_express` VALUES ('10', '宅急送');
INSERT INTO `wuliu_express` VALUES ('11', '德邦物流');
INSERT INTO `wuliu_express` VALUES ('12', 'UPS');
INSERT INTO `wuliu_express` VALUES ('13', '京东物流');
INSERT INTO `wuliu_express` VALUES ('14', '联邦快递');

-- -----------------------------
-- Table structure for `wuliu_member`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_member`;
CREATE TABLE `wuliu_member` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `city` varchar(50) NOT NULL COMMENT '所在站点',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `ix_uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COMMENT='会员表\r\n@author   麦当苗儿\r\n@version  2013-05-27';

-- -----------------------------
-- Records of `wuliu_member`
-- -----------------------------
INSERT INTO `wuliu_member` VALUES ('1', 'airpower', '0', '0000-00-00', '333', '70', '30', '0', '1386481749', '3232235880', '1388198695', '1', '北京化工大学');
INSERT INTO `wuliu_member` VALUES ('26', 'bjhgdx', '0', '0000-00-00', '', '40', '45', '0', '0', '3232235892', '1388390844', '1', '北京化工大学');
INSERT INTO `wuliu_member` VALUES ('42', 'bjhgdx2', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '1', '北京化工大学');
INSERT INTO `wuliu_member` VALUES ('41', 'bjhgdx1', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '1', '北京化工大学');
INSERT INTO `wuliu_member` VALUES ('43', 'bjhgdx3', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '1', '北京化工大学');
INSERT INTO `wuliu_member` VALUES ('44', 'peking', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '1', '');
INSERT INTO `wuliu_member` VALUES ('45', 'shanghai', '0', '0000-00-00', '', '10', '1', '0', '0', '3232235892', '1388455544', '1', '复旦大学');

-- -----------------------------
-- Table structure for `wuliu_model`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_model`;
CREATE TABLE `wuliu_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='文档模型表\r\n@author   麦当苗儿\r\n@version  2013-06-19';

-- -----------------------------
-- Records of `wuliu_model`
-- -----------------------------
INSERT INTO `wuliu_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', 'id:编号\r\ntitle:标题:article/index?cate_id=[category_id]&pid=[id]\r\ntype|get_document_type:类型\r\nlevel:优先级\r\nupdate_time|time_format:最后更新\r\nstatus_text:状态\r\nview:浏览\r\nid:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '0', '', '', '1383891233', '1384507827', '1');
INSERT INTO `wuliu_model` VALUES ('2', 'article', '文章文档', '1', '', '1', '{\"1\":[\"3\",\"2\",\"5\",\"24\"],\"2\":[\"23\",\"14\",\"25\",\"11\",\"9\",\"15\",\"16\",\"10\",\"17\",\"19\",\"13\",\"20\",\"12\",\"26\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题:article/edit?cate_id=[category_id]&id=[id]\r\ncontent:内容', '0', '', '', '1383891243', '1384743355', '1');
INSERT INTO `wuliu_model` VALUES ('3', 'download', '下载文档', '1', '', '1', '{\"1\":[\"29\",\"3\",\"2\",\"5\",\"27\",\"28\",\"30\",\"9\",\"10\",\"12\",\"15\",\"14\",\"11\",\"13\",\"31\",\"17\",\"16\",\"19\",\"32\",\"20\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题', '0', '', '', '1383891252', '1385714025', '1');
INSERT INTO `wuliu_model` VALUES ('4', 'action', '行为定义', '0', '', '1', '{\"1\":[\"33\",\"34\",\"35\",\"36\",\"37\",\"38\",\"39\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891262', '1383891784', '1');
INSERT INTO `wuliu_model` VALUES ('5', 'action_log', '行为日志', '0', '', '1', '{\"1\":[\"40\",\"41\",\"42\",\"43\",\"44\",\"45\",\"46\",\"47\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891340', '1383891802', '1');
INSERT INTO `wuliu_model` VALUES ('6', 'addons', '插件', '0', '', '1', '{\"1\":[\"48\",\"49\",\"50\",\"51\",\"52\",\"53\",\"54\",\"55\",\"56\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891396', '1383891828', '1');
INSERT INTO `wuliu_model` VALUES ('7', 'attachment', '附件', '0', '', '1', '{\"1\":[\"57\",\"58\",\"59\",\"60\",\"61\",\"62\",\"63\",\"64\",\"65\",\"66\",\"67\",\"68\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891410', '1383891847', '1');
INSERT INTO `wuliu_model` VALUES ('8', 'attribute', '属性', '0', '', '1', '{\"1\":[\"69\",\"70\",\"71\",\"72\",\"73\",\"74\",\"75\",\"76\",\"77\",\"78\",\"79\",\"80\",\"81\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891441', '1383891888', '1');
INSERT INTO `wuliu_model` VALUES ('9', 'category', '分类', '0', '', '1', '{\"1\":[\"82\",\"83\",\"84\",\"85\",\"86\",\"87\",\"88\",\"89\",\"90\",\"91\",\"92\",\"93\",\"94\",\"95\",\"96\",\"97\",\"98\",\"99\",\"100\",\"101\",\"102\",\"103\",\"104\",\"105\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891453', '1383891904', '1');
INSERT INTO `wuliu_model` VALUES ('10', 'channel', '前台菜单', '0', '', '1', '{\"1\":[\"106\",\"107\",\"108\",\"109\",\"110\",\"111\",\"112\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891460', '1383891939', '1');
INSERT INTO `wuliu_model` VALUES ('11', 'config', '配置', '0', '', '1', '{\"1\":[\"113\",\"114\",\"115\",\"116\",\"117\",\"118\",\"119\",\"120\",\"121\",\"122\",\"123\"]}', '1:基础', '', '', '', '', 'id:编号\r\nname:名称:edit?id=[id]&model=[MODEL]\r\ntitle:配置', '0', 'title|name', '', '1383891466', '1384248402', '1');
INSERT INTO `wuliu_model` VALUES ('12', 'file', '文件上传', '0', '', '1', '{\"1\":[\"124\",\"125\",\"126\",\"127\",\"128\",\"129\",\"130\",\"131\",\"132\",\"133\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891474', '1383891964', '1');
INSERT INTO `wuliu_model` VALUES ('13', 'hooks', '钩子', '0', '', '1', '{\"1\":[\"134\",\"135\",\"136\",\"137\",\"138\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891480', '1384495820', '1');
INSERT INTO `wuliu_model` VALUES ('14', 'member', '用户信息', '0', '', '1', '{\"1\":[\"139\",\"140\",\"141\",\"142\",\"143\",\"144\",\"145\",\"146\",\"147\",\"148\",\"149\",\"150\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891488', '1386928170', '1');
INSERT INTO `wuliu_model` VALUES ('15', 'menu', '后台菜单', '0', '', '1', '{\"1\":[\"151\",\"152\",\"153\",\"154\",\"155\",\"156\",\"157\",\"158\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891503', '1383892107', '1');
INSERT INTO `wuliu_model` VALUES ('16', 'model', '模型', '0', '', '1', '{\"1\":[\"159\",\"160\",\"161\",\"162\",\"163\",\"164\",\"165\",\"166\",\"167\",\"168\",\"169\",\"170\",\"171\",\"172\",\"173\",\"174\",\"175\",\"176\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891514', '1383892121', '1');
INSERT INTO `wuliu_model` VALUES ('17', 'picture', '图片上传', '0', '', '1', '{\"1\":[\"177\",\"178\",\"179\",\"180\",\"181\",\"182\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891522', '1383892140', '1');
INSERT INTO `wuliu_model` VALUES ('18', 'url', '链接管理', '0', '', '1', '{\"1\":[\"183\",\"184\",\"185\",\"186\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891531', '1385617833', '1');
INSERT INTO `wuliu_model` VALUES ('19', 'sendonline', '即时发货', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1386483287', '1386483287', '1');
INSERT INTO `wuliu_model` VALUES ('20', 'sendover', '已发货表', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1386495714', '1386495714', '1');
INSERT INTO `wuliu_model` VALUES ('21', 'return_goods', '返还表', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1386502685', '1386502685', '1');
INSERT INTO `wuliu_model` VALUES ('22', 'sms', '短信记录表', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1386503290', '1386503290', '1');
INSERT INTO `wuliu_model` VALUES ('23', 'express', '物流公司表', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1386509560', '1386509560', '1');
INSERT INTO `wuliu_model` VALUES ('24', 'receive', '收货', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1387190763', '1387190763', '1');

-- -----------------------------
-- Table structure for `wuliu_receive`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_receive`;
CREATE TABLE `wuliu_receive` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `receive_name` varchar(255) NOT NULL COMMENT '收件人',
  `receive_phone` varchar(255) NOT NULL COMMENT '收件人电话',
  `receive_address` varchar(255) NOT NULL COMMENT '收件人地址',
  `send_name` varchar(255) NOT NULL COMMENT '寄件人',
  `send_phone` varchar(255) NOT NULL COMMENT '寄件人电话',
  `send_address` varchar(255) NOT NULL COMMENT '寄件人地址',
  `weight` varchar(255) NOT NULL COMMENT '重量',
  `price` varchar(255) NOT NULL COMMENT '价格',
  `receive_time` int(10) NOT NULL COMMENT '收货日期',
  `code` varchar(255) NOT NULL COMMENT '快递单号',
  `company_id` int(10) unsigned NOT NULL COMMENT '物流公司',
  `city` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wuliu_receive`
-- -----------------------------
INSERT INTO `wuliu_receive` VALUES ('3', '345', '345', '345', '345', '435', '435', '345', '20', '1387279752', '345', '1', '');
INSERT INTO `wuliu_receive` VALUES ('4', '56456', '456', '456', '456', '456', '456', '456', '10', '1387364523', '456', '1', '');
INSERT INTO `wuliu_receive` VALUES ('5', 'tutyu', '4645', '456', '456', '456', '456', '5345', '15', '1387364533', '456', '1', '');
INSERT INTO `wuliu_receive` VALUES ('6', '435', '345', '北京', '345', '345', '34535', '3', '14', '1388050660', '345435', '3', '');

-- -----------------------------
-- Table structure for `wuliu_return_goods`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_return_goods`;
CREATE TABLE `wuliu_return_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '收货人姓名',
  `code` varchar(255) NOT NULL COMMENT '快递单号',
  `tel` varchar(255) NOT NULL COMMENT '电话',
  `receive_time` int(10) NOT NULL COMMENT '入库时间',
  `back_time` int(10) NOT NULL COMMENT '返还时间',
  `shelf` varchar(255) NOT NULL COMMENT '货架号码',
  `city` varchar(255) NOT NULL COMMENT '所在城市',
  `type` char(10) NOT NULL COMMENT '类型',
  `company_id` int(10) unsigned NOT NULL COMMENT '物流公司',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wuliu_return_goods`
-- -----------------------------
INSERT INTO `wuliu_return_goods` VALUES ('10', 'malina', 'mln123466', '15246258547', '1386999377', '1387001553', '050201', '北京化工大学', '1', '1');
INSERT INTO `wuliu_return_goods` VALUES ('5', 'ghjk', '456', '1233', '1386818050', '1387001668', '13655', '北京化工大学', '1', '1');
INSERT INTO `wuliu_return_goods` VALUES ('19', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387190239', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_return_goods` VALUES ('8', '12323', '010256486665', '123213123', '1386942654', '1388398301', '040210', '北京化工大学', '1', '1');

-- -----------------------------
-- Table structure for `wuliu_sendonline`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_sendonline`;
CREATE TABLE `wuliu_sendonline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '收货人名字',
  `code` varchar(255) NOT NULL COMMENT '快递单号',
  `tel` varchar(255) NOT NULL COMMENT '电话',
  `receive_time` varchar(255) NOT NULL COMMENT '入库时间',
  `city` varchar(255) NOT NULL COMMENT '所在城市',
  `company_id` int(10) unsigned NOT NULL COMMENT '快递公司',
  `type` char(10) NOT NULL DEFAULT '1' COMMENT '类型',
  `shelf` varchar(255) NOT NULL COMMENT '货架号码',
  `remark` text NOT NULL COMMENT '备注',
  `uid` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wuliu_sendonline`
-- -----------------------------
INSERT INTO `wuliu_sendonline` VALUES ('9', '12323', 'hfx248', '15801544589', '1387423032', '北京大学', '1', '1', '020605', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('41', '王瑞麟', '2424wrlin', '15242424895', '1387445407', '北京化工大学', '5', '3', '020204', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('32', '柳柳', 'tgchhbvh', '15110079615', '1387504558', '北京化工大学', '1', '4', '0012', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('34', '贾斌', 'asd258369', '15210340214', '1387473600', '北京化工大学', '3', '4', '070809', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('35', '贾斌', 'kjh1470214', '15210340214', '1388398327', '北京化工大学', '8', '3', '070605', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('37', '王瑞麟', '0874564859', '18242424859', '1387428300', '北京化工大学', '6', '3', '090807', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('38', '王瑞麟', '123456789', '18242424859', '1387364867', '北京化工大学', '4', '1', '070805', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('39', '贾斌', '147258', '15210340214', '1387364993', '北京化工大学', '3', '3', '080705', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('40', '王瑞麟', '123456', '15242424895', '1387473600', '北京化工大学', '3', '4', '080705', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('42', '贾斌', '24jiabin', '15210340214', '1387445694', '北京化工大学', '6', '1', '060504', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('43', '王瑞麟', 'number894', '15242424895', '1387504673', '北京化工大学', '7', '4', '080904', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('44', '贾斌', 'jb1034', '15210340214', '1387446313', '北京化工大学', '5', '2', '010304', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('45', '王瑞麟', 'WRLIN2424', '15242424895', '1387447395', '北京化工大学', '3', '1', '020402', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('46', '贾斌', '0852', '15210340214', '1387448950', '北京化工大学', '8', '3', '080502', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('47', '王先生', 'msw895', '15242424895', '1387449551', '北京化工大学', '3', '4', '040809', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('48', '王瑞瑞', 'wscsh1234', '15242424895', '1387449801', '北京化工大学', '8', '3', '080709', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('49', '小瑞瑞', '1425636w', '15242424895', '1387449981', '北京化工大学', '3', '4', '080470', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('50', 'wrl', 'wrlin123', '15242424895', '1387450339', '北京化工大学', '1', '1', '080906', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('51', '号发货的', '345', '345', '1387871039', '北京化工大学', '1', '1', '35345', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('52', 'ert', '345345', '34534', '1387871483', '北京化工大学', '1', '1', '345435', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('55', '也让他也让', '546546', '456546', '1387872154', '北京化工大学', '1', '1', '54646', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('56', '后返回', '45646576', '546', '1387872335', '北京化工大学', '1', '1', '546', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('57', '天天', '11312190006604', '18612350289', '1388110618', '北京化工大学', '5', '4', '010101', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('58', '贾斌', '1700079060865', '15210340214', '1388110995', '北京化工大学', '7', '4', '010101', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('59', '贾斌', '560057202267', '15210340214', '1388111023', '北京化工大学', '13', '4', '010101', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('60', '贾斌', '350124706109', '15210340214', '1388111048', '北京化工大学', '14', '4', '010101', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('61', '贾斌', '9157188228', '15210340214', '1388111083', '北京化工大学', '3', '4', '010101', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('62', '贾斌', 'EY422437933CS', '15210340214', '1388111113', '北京化工大学', '7', '4', '010101', '个的非官方的5656', '0');
INSERT INTO `wuliu_sendonline` VALUES ('63', '贾斌', '302651158113', '15210340214', '1388211737', '北京化工大学', '4', '1', '090909', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('64', '贾斌', '8048603776', '15210340214', '1388213045', '北京化工大学', '4', '2', '060504', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('65', '贾斌', '17005847YD', '15210340214', '1388213758', '北京化工大学', '5', '1', '070401', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('66', '贾斌', '6922711025933', '15210340214', '1388218181', '北京化工大学', '2', '1', '080808', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('67', '贾斌先生', 'ZJSJBXS123', '15210340214', '1388219180', '北京化工大学', '10', '1', '020202', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('68', '王瑞麟', 'YD4895', '15242424895', '1388221032', '北京化工大学', '3', '1', '050505', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('69', '王瑞麟', 'EMS123456', '15242424895', '1388221226', '北京化工大学', '7', '2', '060606', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('70', '陈', 'chen899', '15243655899', '1388383505', '北京化工大学', '14', '3', '090909', '', '0');
INSERT INTO `wuliu_sendonline` VALUES ('71', '车', 'che0208', '18700010208', '1388384042', '北京化工大学', '13', '3', '020808', '', '0');

-- -----------------------------
-- Table structure for `wuliu_sendover`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_sendover`;
CREATE TABLE `wuliu_sendover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '收货人姓名',
  `code` varchar(255) NOT NULL COMMENT '快递单号',
  `tel` varchar(255) NOT NULL COMMENT '电话',
  `receive_time` int(10) NOT NULL COMMENT '入库时间',
  `send_time` int(10) NOT NULL COMMENT '取货时间',
  `shelf` varchar(255) NOT NULL COMMENT '货架号码',
  `city` varchar(255) NOT NULL COMMENT '城市',
  `type` int(10) unsigned NOT NULL COMMENT '类型',
  `company_id` varchar(255) NOT NULL COMMENT '物流公司',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wuliu_sendover`
-- -----------------------------
INSERT INTO `wuliu_sendover` VALUES ('7', '贾斌', 'jiabin0214', '15210340214', '1386841115', '1387001480', '070205', '北京化工大学', '1', '1');
INSERT INTO `wuliu_sendover` VALUES ('4', 'ghj', '566', '155', '1386818020', '1387014315', '556', '北京化工大学', '0', '2');
INSERT INTO `wuliu_sendover` VALUES ('8', '', '', '', '0', '1387189719', '', '', '0', '');
INSERT INTO `wuliu_sendover` VALUES ('9', '', '', '', '0', '0', '', '', '0', '');
INSERT INTO `wuliu_sendover` VALUES ('27', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387189887', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('25', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387189898', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('24', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387189914', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('23', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387189977', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('26', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387189977', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('21', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387190053', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('22', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387190053', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('18', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387191673', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('16', '贾斌', 'jiabin0234*', '15210340234', '1386840905', '1387191689', '070201', '北京化工大学', '1', '2');
INSERT INTO `wuliu_sendover` VALUES ('33', '贾斌', 'jb0214', '15210340214', '1387361556', '1387362402', '060901', '北京化工大学', '3', '3');
INSERT INTO `wuliu_sendover` VALUES ('36', '王瑞麟', 'wrl4895', '15242424895', '1387363741', '1387365134', '020304', '北京化工大学', '2', '5');
INSERT INTO `wuliu_sendover` VALUES ('12', '12323', 'jiabin0234*', '', '1386840905', '1388398293', '070201', '北京化工大学', '4', '1');

-- -----------------------------
-- Table structure for `wuliu_sms`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_sms`;
CREATE TABLE `wuliu_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sid` int(10) unsigned NOT NULL COMMENT '货物id',
  `sms_status` int(10) unsigned NOT NULL COMMENT '短信状态',
  `goods_status` int(10) unsigned NOT NULL COMMENT '货物状态',
  `comment` text NOT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wuliu_sms`
-- -----------------------------
INSERT INTO `wuliu_sms` VALUES ('3', '9', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('4', '13', '0', '0', '电话号码不正确');
INSERT INTO `wuliu_sms` VALUES ('6', '32', '1', '0', '要取走了');
INSERT INTO `wuliu_sms` VALUES ('10', '34', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('11', '35', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('13', '37', '1', '0', '是我看错了');
INSERT INTO `wuliu_sms` VALUES ('14', '38', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('15', '39', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('16', '40', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('17', '41', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('18', '42', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('19', '43', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('20', '44', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('21', '45', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('22', '46', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('23', '47', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('24', '48', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('25', '49', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('26', '50', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('27', '57', '0', '0', '');
INSERT INTO `wuliu_sms` VALUES ('28', '58', '0', '0', '');
INSERT INTO `wuliu_sms` VALUES ('29', '59', '0', '0', '');
INSERT INTO `wuliu_sms` VALUES ('30', '60', '0', '0', '');
INSERT INTO `wuliu_sms` VALUES ('31', '61', '0', '0', '');
INSERT INTO `wuliu_sms` VALUES ('32', '62', '0', '0', '');
INSERT INTO `wuliu_sms` VALUES ('33', '64', '1', '0', '');
INSERT INTO `wuliu_sms` VALUES ('34', '70', '0', '0', '');
INSERT INTO `wuliu_sms` VALUES ('35', '71', '0', '0', '');

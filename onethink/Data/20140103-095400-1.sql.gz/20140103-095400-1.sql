-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : wuliu
-- 
-- Part : #1
-- Date : 2014-01-03 09:54:01
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `wuliu_area_price`
-- -----------------------------
DROP TABLE IF EXISTS `wuliu_area_price`;
CREATE TABLE `wuliu_area_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `plusprice` int(11) NOT NULL,
  `discount` int(11) NOT NULL COMMENT '折扣',
  `company_id` int(11) NOT NULL,
  `city` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `wuliu_area_price`
-- -----------------------------
INSERT INTO `wuliu_area_price` VALUES ('1', '山东、天津、河南、河北', '12', '8', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('2', '江苏、浙江、上海、安徽、山西、陕西、黑龙江、辽宁、吉林、广东、湖南、湖北', '12', '8', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('3', '福建、广西、海南、重庆、四川、贵州、云南、甘肃、宁夏、内蒙古', '15', '12', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('4', '新疆、西藏、青海', '22', '20', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('5', '北京', '8', '3', '0', '3', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('6', '河北、天津、山东、江浙沪、广东', '10', '6', '0', '8', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('7', '河南、安徽、山西、江西、陕西、黑龙江、吉林、辽宁、湖南、湖北、福建、重庆、四川', '12', '8', '0', '8', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('8', '广西、海南、内蒙古、甘肃、宁夏、云南', '15', '10', '0', '8', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('9', '新疆、西藏、青海', '22', '20', '0', '8', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('10', '北京', '8', '3', '0', '8', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('11', '河北、天津、山东、江浙沪、广东', '10', '6', '0', '10', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('12', '河南、安徽、山西、江西、陕西、黑龙江、吉林、辽宁、湖南、湖北、福建、重庆、四川', '12', '8', '0', '10', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('13', '广西、海南、内蒙古、甘肃、宁夏、云南', '15', '10', '0', '10', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('14', '新疆、西藏、青海', '22', '20', '0', '10', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('15', '北京', '8', '3', '0', '10', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('16', '河北、天津、山东、江浙沪、广东', '10', '6', '0', '9', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('17', '河南、安徽、山西、江西、陕西、黑龙江、吉林、辽宁、湖南、湖北、福建、重庆、四川', '12', '8', '0', '9', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('18', '广西、海南、内蒙古、甘肃、宁夏、云南', '15', '10', '0', '9', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('19', '新疆、西藏、青海', '22', '20', '0', '9', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('20', '北京', '8', '3', '0', '9', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('21', '河北、天津、山东、江浙沪、广东', '10', '6', '0', '6', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('22', '河南、安徽、山西、江西、陕西、黑龙江、吉林、辽宁、湖南、湖北、福建、重庆、四川', '12', '8', '0', '6', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('23', '广西、海南、内蒙古、甘肃、宁夏、云南', '15', '10', '0', '6', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('24', '新疆、西藏、青海', '22', '20', '0', '6', '北京化工大学');
INSERT INTO `wuliu_area_price` VALUES ('25', '北京', '8', '3', '0', '6', '北京化工大学');
